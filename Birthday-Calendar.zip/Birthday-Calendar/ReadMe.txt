To Run:

Just open index.html in a browser, enter the array of objects data as given below and an year.


Technical Description:

Created with plain HTML, CSS and Javascript ES5. Accepts an array of objects in the format given below.

Sample Data:

[{
		"name": "Tyrion Lannister",
		"birthday": "12/02/1975"
	},
	{
		"name": "Cersei Lannister",
		"birthday": "11/30/1975"
	},
	{
		"name": "Daenerys Targaryen",
		"birthday": "11/24/1975"
	},
	{
		"name": "Arya Stark",
		"birthday": "11/25/1975"
	},
	{
		"name": "Arya Stark",
		"birthday": "11/25/1975"
	},
	{
		"name": "Arya Stark",
		"birthday": "11/25/1975"
	},
	{
		"name": "Arya Stark",
		"birthday": "11/25/1975"
	},
	{
		"name": "Arya Stark",
		"birthday": "11/25/1975"
	},
	{
		"name": "Arya Stark",
		"birthday": "11/25/1975"
	},
	{
		"name": "Arya Stark",
		"birthday": "11/25/1975"
	},
	{
		"name": "Arya Stark",
		"birthday": "11/25/1975"
	},
	{
		"name": "Arya Stark",
		"birthday": "11/25/1975"
	},
	{
		"name": "Arya Stark",
		"birthday": "11/25/1975"
	},
	{
		"name": "Arya Stark",
		"birthday": "11/25/1975"
	},
	{
		"name": "Arya Stark",
		"birthday": "11/25/1975"
	},
	{
		"name": "Jon Snow",
		"birthday": "12/03/1975"
	},
	{
		"name": "Sansa Stark",
		"birthday": "15/08/1975"
	},
	{
		"name": "Jorah Mormont",
		"birthday": "12/16/1975"
	},
	{
		"name": "Jaime Lannister",
		"birthday": "12/06/1975"
	},
	{
		"name": "Sandor Clegane",
		"birthday": "11/07/2018"
	},
	{
		"name": "Tywin Lannister",
		"birthday": "10/12/1975"
	},
	{
		"name": "Theon Greyjoy",
		"birthday": "12/31/1975"
	},
	{
		"name": "Samwell Tarly",
		"birthday": "12/07/1975"
	},
	{
		"name": "Joffrey Baratheon",
		"birthday": "06/12/1975"
	},
	{
		"name": "Catelyn Stark",
		"birthday": "12/03/1975"
	},
	{
		"name": "Bran Stark",
		"birthday": "12/02/1975"
	},
	{
		"name": "Petyr Baelish",
		"birthday": "11/20/1975"
	},
	{
		"name": "Robb Stark",
		"birthday": "11/28/2018"
	},
	{
		"name": "Brienne of Tarth",
		"birthday": "11/27/1975"
	},
	{
		"name": "Margaery Tyrell",
		"birthday": "12/02/1975"
	},
	{
		"name": "Stannis Baratheon",
		"birthday": "09/14/1975"
	},
	{
		"name": "Davos Seaworth",
		"birthday": "02/13/1975"
	},
	{
		"name": "Tormund Giantsbane",
		"birthday": "12/14/1975"
	},
	{
		"name": "Jeor Mormont",
		"birthday": "11/01/1975"
	},
	{
		"name": "Eddard Stark",
		"birthday": "12/02/1975"
	},
	{
		"name": "Khal Drogo",
		"birthday": "12/05/2018"
	},
	{
		"name": "Ramsay Bolton",
		"birthday": "12/05/2018"
	},
	{
		"name": "Robert Baratheon",
		"birthday": "12/02/1975"
	},
	{
		"name": "Daario Naharis",
		"birthday": "12/02/1975"
	},
	{
		"name": "Viserys Targaryen",
		"birthday": "12/32/1975"
	}
]

And enter an year.

Within that year, it will calculate the day of the week and populate the initials on the respective cells. Used plain browser alert to display of there are any errors/exceptions. Used momentjs and ramdajs for date manipulation and immutable manipulation respectively.


Further Development:
    Can perform Unit tests.
    Can implement this main.js into Sagas ( if react app) or Services ( if angular app ).

