function getPeopleFromYear(year, peopleFromYear) {
    var convertToDateObj = function (person) {
        return R.assoc('birthday', moment(person.birthday).format(), person);
    }

    var isSameYear = function (person) {
        return moment(year).format('YYYY') === moment(person.birthday).format('YYYY');
    }

    return R.filter(isSameYear, R.map(convertToDateObj, peopleFromYear));
}

function groupByWeekDay(peopleFromYear) {
    var addWeekDay = function (person) {
        return R.assoc('weekDay', moment(person.birthday).format('dddd'), person);
    }

    return R.groupBy(R.prop('weekDay'), R.map(addWeekDay, peopleFromYear))
}

function sortByAge(groupedPeople) {
    var addDateObj = function (groupedPeople) {
        return R.sortBy(R.prop('birthday'), groupedPeople)
    }

    return R.map(addDateObj, groupedPeople);
}

function createAcronym(person) {
    var matches = person.name.match(/\b(\w)/g);
    return R.assoc('acronym', matches.join(''), person);
}

function getPersonItemClass(data) {
    if(data.length) {
        if(data.length > 9) {
            return 'cell-4';
        } else if(data.length > 4) {
            return 'cell-3';
        } else if(data.length > 1) {
            return 'cell-2';
        } else {
            return 'cell-1';
        }
    }
    return;
}

function peopleDOMToDisplay(data) {
    var dataWithAcronym = R.map(createAcronym, data);
    var createDayPerson = function (person) {
        return '<div class="day__person ' + getPersonItemClass(data) + '">' + person.acronym + '</div>'
    }

    return R.map(createDayPerson, dataWithAcronym)
}

function setLabel(data, parentNode) {
    var labelNodes = parentNode.querySelectorAll('label');
    labelNodes[0].innerHTML = (data && data.length || 'No') + ' birthday';
    labelNodes[0].innerHTML += (!data || data.length === 0 || data.length > 1) ? 's' : '';
}

function addRemoveEmptyClass(data, parentNode) {
    var appendTo = parentNode.querySelectorAll('.day__people');
    !data || data.length === 0 ?
    appendTo[0].classList.add('day--empty') :
    appendTo[0].classList.remove('day--empty');
}

function setDomToDisplay(data, parentNode) {
    var appendTo = parentNode.querySelectorAll('.day__people');
    if (data) {
        var domToDisplay = peopleDOMToDisplay(data).join('');
        appendTo[0].innerHTML = domToDisplay;
    } else {
        appendTo[0].innerHTML = '';
    }
}

function setWeekDayView(weekDay, data) {
    var parentLi = document.querySelectorAll('[data-day="' + weekDay + '"]');
    setLabel(data, parentLi[0]);
    addRemoveEmptyClass(data, parentLi[0])
    setDomToDisplay(data, parentLi[0]);
}

function parseJSON(string) {
    return JSON.parse(R.replace(/([{,])(\s*)([A-Za-z0-9_\-]+?)\s*:/g, '$1"$3":', string))
}

function updateCalendar() {
    var jsonInput = document.querySelector('#json-input');
    var chosenYear = document.querySelector('#chosen-year');

    try {
        if (jsonInput.value
            && jsonInput.value != ''
            && parseJSON(jsonInput.value)
            && chosenYear.value
            && chosenYear.value != ''
            && moment(chosenYear.value).format('YYYY') != ''
        ) {
            var data = parseJSON(jsonInput.value);
            var year = moment(chosenYear.value).format('YYYY');
            var calendarData = sortByAge(
                groupByWeekDay(
                    getPeopleFromYear(year, data)
                )
            );
            setWeekDayView('mon', calendarData.Monday)
            setWeekDayView('tue', calendarData.Tuesday)
            setWeekDayView('wed', calendarData.Wednesday)
            setWeekDayView('thu', calendarData.Thursday)
            setWeekDayView('fri', calendarData.Friday)
            setWeekDayView('sat', calendarData.Saturday)
            setWeekDayView('sun', calendarData.Sunday)

        } else {
            alert('Invalid inputs');
        }

    } catch (e) {
        alert(e);
    }
}